﻿namespace _04.Distance_Between_Points
{
    class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

    }
}
